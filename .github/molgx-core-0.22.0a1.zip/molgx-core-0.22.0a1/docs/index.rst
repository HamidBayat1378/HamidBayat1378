.. MolGX documentation master file, created by
   sphinx-quickstart on Fri Jul 27 15:10:01 2018.
   You can adapt this file completely to your liking, but it should at least
   contain the root `toctree` directive.

Welcome to MolGX documentation!
===============================

.. toctree::
   :maxdepth: 2
   :caption: Contents:

   intro.rst
   tutorial.rst
   reference.rst
   release.rst


Indices and tables
==================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`

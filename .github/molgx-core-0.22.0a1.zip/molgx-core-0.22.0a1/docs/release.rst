.. _release_note:

.. py:currentmodule:: molgx

*************
Release Notes
*************

.. _release_0.22.0a0:


Release v0.22.0a0
=================

:Release date: Mar. 31, 2022

This is a first alpha release of the Community Version of IBM Molecule Generation Experience (MolGX).
